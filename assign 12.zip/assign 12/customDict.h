#ifndef CUSTOMDICT_H
#define CUSTOMDICT_H

typedef union Value
{
    int *int_value;
    char *char_value;
    float *float_value;
    double *double_value;
}Value;

typedef struct Item{
    char *key;
    Value values;
}Item;

typedef struct CustomDict{
    int curr_size;
    int curr_capacity;
    Item *items;
}CustomDict;

CustomDict* create_dict();
void add_item(struct CustomDict* dict, char* key, union Value* value);
void delete_item(struct CustomDict* dict, char* key);
void set_value(struct CustomDict* dict, char* key, union Value* value);
Value* search_item(struct CustomDict* dict, char* key);
void sort_dict(struct CustomDict* dict);
void print_dict(struct CustomDict* dict);
void free_dict(struct CustomDict* dict);
int read_csv(struct CustomDict* dict, const char* filename);
#endif /* CUSTOMDICT_H */