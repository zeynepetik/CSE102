#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "customDict.h"

CustomDict *create_dict()
{
    CustomDict *dict = (CustomDict *)malloc(sizeof(CustomDict));
    dict->curr_capacity = 0;
    dict->items = (Item *)malloc(sizeof(Item) * dict->curr_capacity);
    dict->curr_size = 0;
    return dict;
}
void add_item(CustomDict *dict, char *key, Value *value)
{
    int i;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, key)) == 0)
        {
            if ((strcmp(key, "age")) == 0 || strcmp(key, "score") == 0 || (strcmp(key, "quantity")) == 0 || (strcmp(key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
            {
                free(dict->items[i].values.int_value);
                dict->items[i].values.int_value = (int *)malloc(sizeof(int));
                dict->items[i].values.int_value = value->int_value;
            }
            if ((strcmp(key, "balance")) == 0 || (strcmp(key, "distance")) == 0 || (strcmp(key, "amount")) == 0 || (strcmp(key, "price")) == 0 || (strcmp(key, "weight")) == 0)
            {
                free(dict->items[i].values.double_value);
                dict->items[i].values.double_value = (double *)malloc(sizeof(double));
                dict->items[i].values.double_value = value->double_value;
            }
            if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
            {
                free(dict->items[i].values.float_value);
                dict->items[i].values.float_value = (float *)malloc(sizeof(float));
                dict->items[i].values.float_value = value->float_value;
            }
            if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
            {
                free(dict->items[i].values.char_value);
                dict->items[i].values.char_value = (char *)malloc(sizeof(char));
                dict->items[i].values.char_value = value->char_value;
            }
            return;
        }
    }
    if (dict->curr_size == dict->curr_capacity)
    {
        dict->curr_capacity += 5;
        dict->items = (Item *)realloc(dict->items, sizeof(Item) * dict->curr_capacity);
    }
    /*allocate memory for key for that index of item*/
    dict->items[dict->curr_size].key = (char *)malloc(strlen(key) + 1);
    dict->items[dict->curr_size].key = key;
    /*store the data according to its type*/
    if ((strcmp(key, "age")) == 0 || strcmp(key, "score") == 0 || (strcmp(key, "quantity")) == 0 || (strcmp(key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
    {
        dict->items[i].values.int_value = (int *)malloc(sizeof(int));
        dict->items[i].values.int_value = value->int_value;
    }
    if ((strcmp(key, "balance")) == 0 || (strcmp(key, "distance")) == 0 || (strcmp(key, "amount")) == 0 || (strcmp(key, "price")) == 0 || (strcmp(key, "weight")) == 0)
    {
        dict->items[i].values.double_value = (double *)malloc(sizeof(double));
        dict->items[i].values.double_value = value->double_value;
    }
    if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
    {
        dict->items[i].values.float_value = (float *)malloc(sizeof(float));
        dict->items[i].values.float_value = value->float_value;
    }
    if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
    {
        dict->items[i].values.char_value = (char *)malloc(sizeof(char));
        dict->items[i].values.char_value = value->char_value;
    }
    dict->curr_size++;
}

void delete_item(CustomDict *dict, char *key)
{
    int i, j;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, key)) == 0)
        {
            if ((strcmp(key, "age")) == 0 || strcmp(key, "score") == 0 || (strcmp(key, "quantity")) == 0 || (strcmp(key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
            {
                free(dict->items[i].values.int_value);
            }
            if ((strcmp(key, "balance")) == 0 || (strcmp(key, "distance")) == 0 || (strcmp(key, "amount")) == 0 || (strcmp(key, "price")) == 0 || (strcmp(key, "weight")) == 0)
            {
                free(dict->items[i].values.double_value);
            }
            if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
            {
                free(dict->items[i].values.float_value);
            }
            if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
            {
                free(dict->items[i].values.char_value);
            }
            /*free the memory for key and values of that index*/
            free(dict->items[i].key);
            /*move elemnts of the array*/
            for (j = i + 1; j < dict->curr_size; j++)
            {
                dict->items[j - 1] = dict->items[j];
            }
            /*decrease the size*/
            dict->curr_size--;
        }
    }
}

void set_value(CustomDict *dict, char *key, Value *value)
{
    int i;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, key)) == 0)
        {
            /*acoording to its type free the memory */
            if ((strcmp(key, "age")) == 0 || strcmp(key, "score") == 0 || (strcmp(key, "quantity")) == 0 || (strcmp(key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
            {
                free(dict->items[i].values.int_value);
                dict->items[i].values.int_value = (int *)malloc(sizeof(int));
                dict->items[i].values.int_value = value->int_value;
            }
            if ((strcmp(key, "balance")) == 0 || (strcmp(key, "distance")) == 0 || (strcmp(key, "amount")) == 0 || (strcmp(key, "price")) == 0 || (strcmp(key, "weight")) == 0)
            {
                free(dict->items[i].values.double_value);
                dict->items[i].values.double_value = (double *)malloc(sizeof(double));
                dict->items[i].values.double_value = value->double_value;
            }
            if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
            {
                free(dict->items[i].values.float_value);
                dict->items[i].values.float_value = (float *)malloc(sizeof(float));
                dict->items[i].values.float_value = value->float_value;
            }
            if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
            {
                free(dict->items[i].values.char_value);
                dict->items[i].values.char_value = (char *)malloc(sizeof(char));
                dict->items[i].values.char_value = value->char_value;
            }
        }
    }
}
Value *search_item(CustomDict *dict, char *key)
{
    int i, j;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, key)) == 0)
        {
            return &(dict->items[i].values);
        }
    }
    return NULL; /*if key is not found return null*/
}
void sort_dict(CustomDict *dict)
{
    int i, j;
    for (i = 0; i < dict->curr_size - 1; i++)
    {
        for (j = 0; dict->curr_size - i - 1; j++)
        {
            if ((strcmp(dict->items[j].key, dict->items[j + 1].key)) > 0)
            {
                Item temp = dict->items[j];
                dict->items[j] = dict->items[j + 1];
                dict->items[j + 1] = temp;
            }
        }
    }
}
void print_dict(CustomDict *dict)
{
    int i, j = 0;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, "age")) == 0 || (strcmp(dict->items[i].key, "score")) == 0 || (strcmp(dict->items[i].key, "quantity")) == 0 || (strcmp(dict->items[i].key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
            printf("KEY:%s ,VALUE:%d\n", dict->items->key, *(dict->items[i].values.int_value));
        if ((strcmp(dict->items[i].key, "balance")) == 0 || (strcmp(dict->items[i].key, "distance")) == 0 || (strcmp(dict->items[i].key, "amount")) == 0 || (strcmp(dict->items[i].key, "price")) == 0 || (strcmp(dict->items[i].key, "weight")) == 0)
            printf("KEY:%s ,VALUE:%.2lf\n", dict->items->key, *(dict->items[i].values.int_value));
        if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
            printf("KEY:%s ,VALUE:%.2f\n", dict->items->key, *(dict->items[i].values.int_value));
        if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
            printf("KEY:%s ,VALUE:%c\n", dict->items->key, *(dict->items[i].values.char_value));
    }
}
void free_dict(CustomDict *dict)
{
    int i;
    for (i = 0; i < dict->curr_size; i++)
    {
        if ((strcmp(dict->items[i].key, "age")) == 0 || (strcmp(dict->items[i].key, "score")) == 0 || (strcmp(dict->items[i].key, "quantity")) == 0 || (strcmp(dict->items[i].key, "count")) == 0 || (strcmp(dict->items[i].key, "size")) == 0)
            free(dict->items[i].values.int_value);
        if ((strcmp(dict->items[i].key, "balance")) == 0 || (strcmp(dict->items[i].key, "distance")) == 0 || (strcmp(dict->items[i].key, "amount")) == 0 || (strcmp(dict->items[i].key, "price")) == 0 || (strcmp(dict->items[i].key, "weight")) == 0)
            free(dict->items[i].values.double_value);
        if ((strcmp(dict->items[i].key, "height")) == 0 || (strcmp(dict->items[i].key, "value")) == 0 || (strcmp(dict->items[i].key, "temprature")) == 0 || (strcmp(dict->items[i].key, "speed")) == 0)
            free(dict->items[i].values.float_value);
        if ((strcmp(dict->items[i].key, "blood_type")) == 0 || (strcmp(dict->items[i].key, "letter")) == 0)
            free(dict->items[i].values.char_value);

        free(dict->items[i].key);
    }
    free(dict->items);
    free(dict);
}
int read_csv(struct CustomDict *dict, const char *filename)
{
    FILE *fp = fopen(filename, "r");
    char type[5];
    Value *val;
    char ch_val, ch, key[12];
    if (fp == NULL)
    {
        return 0;
    }
    else
    {
        while (fscanf(fp, "%s,%s,", type, key) != EOF)
            ;
        if ((strcmp(dict->items->key, "age")) == 0 || (strcmp(dict->items->key, "score")) == 0 || (strcmp(dict->items->key, "quantity")) == 0 || (strcmp(dict->items->key, "count")) == 0 || (strcmp(dict->items->key, "size")) == 0)
        {
            do
            {
                fscanf(fp, "%d", &val->int_value);
                add_item(dict, key, val);
                fscanf(fp, "%c", &ch);
            } while (ch != '\n');
        }
        if ((strcmp(dict->items->key, "balance")) == 0 || (strcmp(dict->items->key, "distance")) == 0 || (strcmp(dict->items->key, "amount")) == 0 || (strcmp(dict->items->key, "price")) == 0 || (strcmp(dict->items->key, "weight")) == 0)
        {
            do
            {
                fscanf(fp, "%lf", &val->float_value);
                add_item(dict, key, val);
                fscanf(fp, "%c", &ch);
            } while (ch != '\n');
        }

        if ((strcmp(dict->items->key, "height")) == 0 || (strcmp(dict->items->key, "value")) == 0 || (strcmp(dict->items->key, "temprature")) == 0 || (strcmp(dict->items->key, "speed")) == 0)
        {
            do
            {
                fscanf(fp, "%f", &val->float_value);
                add_item(dict, key, val);
                fscanf(fp, "%c", &ch);
            } while (ch != '\n');
        }

        if ((strcmp(dict->items->key, "blood_type")) == 0 || (strcmp(dict->items->key, "letter")) == 0)
        {
            do
            {
                fscanf(fp, "%c", &val->char_value);
                add_item(dict, key, val);
                fscanf(fp, "%c", &ch);
            } while (ch != '\n');
        }
    }
    return 1;
}
int main()
{
    CustomDict *dict = create_dict();
    char filename[] = "data.csv";
    int sucess = read_csv(dict, filename);
    if (sucess == 0)
    {
        printf("Can not read the data\n");
    }
    else
    {
        printf("Reading is sucessful\n");
        print_dict(dict);
    }
    free_dict(dict);
}